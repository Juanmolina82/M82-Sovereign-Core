#!/usr/bin/env python3
import asyncio, json, os, re, sqlite3, websockets, requests

DB_PATH = os.path.expanduser("~/M82/m82_database.db")
ENV_PATH = os.path.expanduser("~/M82/.env")

def load_env():
    env_vars = {}
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env_vars[k.strip()] = v.strip().strip('"').strip("'")
    return env_vars

ENV = load_env()
CLIENT_ID = ENV.get("LSEG_API_KEY", "")
CLIENT_SECRET = ENV.get("LSEG_CLIENT_SECRET", "")
USERNAME = ENV.get("LSEG_USERNAME", "")
PASSWORD = ENV.get("LSEG_PASSWORD", "")

AUTH_URL = "https://api.refinitiv.com/auth/oauth2/v1/token"
WEBSOCKET_URL = "wss://api.refinitiv.com/streaming/pricing/v1/"

RIC_MAP = {
    "VE008983021=": "VENZ34",
    "VE029436720=": "PDVSA26",
    "CLc1": "WTI",
    "LCOc1": "BRENT",
    "XAU=": "XAUUSD",
    "BTC=": "BTCUSD"
}

def save_price_tick(ric, bid, ask, last_price):
    asset_name = RIC_MAP.get(ric, ric)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("""
            INSERT INTO price_ticks (asset, bid, ask, last_price, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(asset) DO UPDATE SET
                bid = COALESCE(excluded.bid, price_ticks.bid),
                ask = COALESCE(excluded.ask, price_ticks.ask),
                last_price = COALESCE(excluded.last_price, price_ticks.last_price),
                updated_at = CURRENT_TIMESTAMP
        """, (asset_name, bid, ask, last_price))
        conn.commit()
    except Exception: pass
    finally: conn.close()

def get_token():
    if not CLIENT_ID or "YOUR_" in CLIENT_ID: return None
    data = {'grant_type': 'password', 'username': USERNAME, 'password': PASSWORD, 'client_id': CLIENT_ID, 'takeExclusiveSignOnControl': 'true', 'scope': 'trap'}
    try:
        res = requests.post(AUTH_URL, data=data, timeout=10)
        return res.json().get("access_token") if res.status_code == 200 else None
    except Exception: return None

async def lseg_ws_stream():
    token = get_token()
    if not token:
        await asyncio.sleep(60)
        return
    try:
        async with websockets.connect(WEBSOCKET_URL, extra_headers={"Authorization": f"Bearer {token}"}) as ws:
            await ws.send(json.dumps({"ID": 1, "Domain": "Login", "Key": {"NameType": "AuthToken", "Elements": {"ApplicationId": "256", "Position": "127.0.0.1/net", "AuthenticationToken": token}}}))
            await ws.send(json.dumps({"ID": 2, "Key": {"Name": ["N2_UBMS", "NEWS_ALL"], "Service": "ELEKTRON_DD"}}))
            await ws.send(json.dumps({"ID": 3, "Key": {"Name": list(RIC_MAP.keys()), "Service": "ELEKTRON_DD"}}))
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                for item in data if isinstance(data, list) else [data]:
                    if item.get("Type") in ["Update", "Refresh"]:
                        fields = item.get("Fields", {})
                        ric_name = item.get("Key", {}).get("Name", "")
                        if any(f in fields for f in ["CF_BID", "CF_ASK", "CF_LAST", "TRDPRC_1"]):
                            save_price_tick(ric_name, fields.get("CF_BID"), fields.get("CF_ASK"), fields.get("CF_LAST") or fields.get("TRDPRC_1"))
                    elif item.get("Type") == "Ping":
                        await ws.send(json.dumps({"Type": "Pong"}))
    except Exception:
        await asyncio.sleep(10)

if __name__ == "__main__":
    asyncio.run(lseg_ws_stream())
