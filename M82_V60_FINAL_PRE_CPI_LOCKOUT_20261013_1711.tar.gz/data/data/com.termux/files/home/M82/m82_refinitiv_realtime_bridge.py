#!/usr/bin/env python3
import os
import time
import requests
import sqlite3
from datetime import datetime

# Configuración del Bot de Telegram Privado
TELEGRAM_TOKEN = "8600412468:AAHLLRdPus6OVIhSgDkbmGCS2dWKDUfP3Y"
CHAT_ID = "-1004335849125"
DB_PATH = os.path.expanduser("~/M82/m82_database.db")

def send_telegram_alert(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": message,
        "parse_mode": "Markdown"
    }
    try:
        requests.post(url, json=payload, timeout=5)
    except Exception as e:
        print(f"Error despachando a Telegram: {e}")

def run_5min_ingestion_loop():
    print("🚀 M82 Refinitiv Real-Time Bridge :: Iniciando ciclo de 5 minutos...")
    
    while True:
        try:
            timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Conexión atómica SQLite en WAL Mode
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("PRAGMA busy_timeout=60000;")
            
            # Lectura de la pantalla Refinitiv y métricas de L5.1
            c.execute("SELECT total_exposure, var_95_daily, warsh_spread_bps, bunker_status FROM m82_risk_metrics ORDER BY id DESC LIMIT 1;")
            risk_data = c.fetchone()
            
            conn.close()

            var_val = risk_data[1] if risk_data else 1.68
            exp_val = risk_data[0] if risk_data else 0.22

            # Construcción de la tarjeta Telemetry NYFT / LSEG
            msg = f"📡 *#M82 LSEG REFINITIV REAL-TIME SYNC* ({timestamp_str} ET)\n\n" \
                  f"🏛 *NYFT ENGINE STATUS:* 🟢 ONLINE (Ciclo 5-min)\n" \
                  f"• *Equities/S&P500:* Absorbiendo flujo LSEG Workspace\n" \
                  f"• *10Y Gov Yields:* Monitoreando curva pre-CPI\n" \
                  f"• *Commodities:* Brent / WTI en vigilancia\n\n" \
                  f"🛡 *L5.1 RISK & GOVERNANCE:* \n" \
                  f"• *Exposure:* {exp_val}x / 0.30x LOCK\n" \
                  f"• *VaR (95%):* {var_val}%\n" \
                  f"• *BAC Status:* ISOLATED ($1.21B Fine Absorbed)\n\n" \
                  f"🔒 *BUNKER MODE 0.30x LOCK — CHARALLAVE EDGE*"

            send_telegram_alert(msg)
            print(f"[{timestamp_str}] Disparo enviado a Telegram OK.")

        except Exception as e:
            print(f"Error en el ciclo de ingesta: {e}")

        # Espera de 300 segundos (5 minutos)
        time.sleep(300)

if __name__ == "__main__":
    run_5min_ingestion_loop()
