#!/usr/bin/env python3
import os, time, sqlite3, re

DB_PATH = os.path.expanduser("~/M82/m82_database.db")
BEARISH_WORDS = {"fall", "drop", "decline", "cut", "sanction", "ban", "deficit", "loss", "down"}
BULLISH_WORDS = {"rise", "gain", "surge", "growth", "approve", "profit", "rally", "up"}

def calculate_score(headline):
    words = re.findall(r'\w+', headline.lower())
    if not words: return 0.0
    bull = sum(1 for w in words if w in BULLISH_WORDS)
    bear = sum(1 for w in words if w in BEARISH_WORDS)
    tot = bull + bear
    return round((bull - bear) / tot, 2) if tot > 0 else 0.0

def run_ingest_cycle():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    sample_signals = [
        ("CITGO_OFAC_DESK", "OFAC approves major energy license extension for debt swap", "VENZ34, PDVSA26"),
        ("REUTERS_TOP", "Central Banks surge gold reserve accumulation amidst rate decline", "XAUUSD"),
        ("VE_OIL_LEGAL", "Chevron increases output target for joint venture crude export", "WTI, PDVSA26")
    ]
    for source, headline, asset in sample_signals:
        score = calculate_score(headline)
        try:
            c.execute("INSERT INTO m82_multi_stream (daemon_source, headline, alpha_score, asset_impact) VALUES (?, ?, ?, ?)", (source, headline, score, asset))
        except sqlite3.IntegrityError:
            pass
    conn.commit()
    conn.close()

if __name__ == "__main__":
    while True:
        try: run_ingest_cycle()
        except Exception as e: print(f"⚠️ Error Ingest: {e}")
        time.sleep(180)
