#!/usr/bin/env python3
import os, time, sqlite3, requests

DB_PATH = os.path.expanduser("~/M82/m82_database.db")
NTFY_URL = "https://ntfy.sh/M82-Molina-Alerts-v2"

# Muestreo exclusivo para TOP NEWS de alto Alpha (> 0.85)
def process_top_news_dispatch():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA busy_timeout=60000;")
        c = conn.cursor()
        
        # Seleccionar únicamente items PENDING de alto impacto (Alpha >= 0.85)
        c.execute("""
            SELECT rowid, daemon_source, headline, alpha_score, asset_impact 
            FROM m82_multi_stream 
            WHERE status = 'PENDING' AND alpha_score >= 0.85 
            ORDER BY rowid ASC LIMIT 1
        """)
        row = c.fetchone()
        
        if row:
            row_id, src, headline, alpha, asset = row
            
            # Enviar notificación limpia a ntfy.sh
            payload = f"🚨 [TOP NEWS | M82 QUANT]\nSource: {src}\nAsset: {asset} | Alpha: {alpha}\n\n{headline}\n\n🏛 @MolinaHoldings | AGI Quantum Node"
            headers = {
                "Title": f"M82 ALERT: {src} [{asset}]",
                "Priority": "high" if alpha >= 0.90 else "default",
                "Tags": "chart_with_upwards_trend,warning"
            }
            
            try:
                requests.post(NTFY_URL, data=payload.encode('utf-8'), headers=headers, timeout=3)
            except Exception as e:
                pass

            # MARCAR COMO PROCESADO INMEDIATAMENTE PARA EVITAR BUCLE
            c.execute("UPDATE m82_multi_stream SET status = 'PROCESSED' WHERE rowid = ?", (row_id,))
            conn.commit()
            print(f"✅ [DISPATCHED & SEALED] Row {row_id} | {src} -> {asset}")
        else:
            # Limpiar cualquier residuo de bajo alpha que haya quedado en PENDING
            c.execute("UPDATE m82_multi_stream SET status = 'SKIPPED' WHERE status = 'PENDING' AND alpha_score < 0.85")
            conn.commit()

        conn.close()
    except Exception as err:
        pass

if __name__ == "__main__":
    print("🚀 [M82 ORCHESTRATOR v4] Top News Filter & Zero-Loop Engine Active...")
    while True:
        process_top_news_dispatch()
        time.sleep(5)
