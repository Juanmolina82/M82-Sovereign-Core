#!/usr/bin/env python3
from flask import Flask, request, jsonify
import sqlite3, os

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

BASE_DIR = os.path.expanduser("~/M82")
DB_PATH = os.path.join(BASE_DIR, "m82_database.db")

@app.route('/', methods=['POST'])
def analyze():
    data = request.get_json(force=True)
    msg = data.get("message", "").lower()

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT source, category, headline, risk_score FROM macro_dosier ORDER BY id DESC LIMIT 1")
    row = c.fetchone()
    conn.close()

    source = row[0] if row else "M82_WIRE_WORKSPACE_M82_MACRO"
    category = row[1] if row else "VEN_BONDS_RALLY"
    headline = row[2] if row else "Venezuela debt rally sees eyes on higher recovery price"
    risk = row[3] if row else 9.2

    hud_image_url = f"http://127.0.0.1:8080/hud_PE_LARGEST_FUNDS_DESK.png"

    response_text = (
        f"=== DESGLOSE EJECUTIVO Y MATRIZ DE IMPACTO M82 ===\n"
        f"🚨 [RISK {risk}] {category}\n"
        f"📌 {headline}\n\n"
        f"![HUD M82]({hud_image_url})\n\n"
        f"• Cobertura M82 Wire: Cables de bonos sovereign, Lazard restructuring y Chevron CVX.N activos.\n"
        f"• Dry Powder Global PE: $2.008 Trillones en 1,873 fondos.\n"
        f"• Estado Nodo Charallave: 40 Daemons en Lite Polling + Wake-Lock Habilitado."
    )

    return jsonify({"response": response_text})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8083)
