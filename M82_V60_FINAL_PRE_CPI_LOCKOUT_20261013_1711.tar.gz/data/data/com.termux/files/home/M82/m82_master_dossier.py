import concurrent.futures
import sqlite3
import time
import os
import random
from datetime import datetime

DB_PATH = os.path.expanduser("~/M82/m82_database.db")

DAEMONS_LIST = [
    "HOUTHI_SAUDI_MISSILE", "US_CARIBBEAN_MILITARY", "US_SOUTHERN_COMMAND", "SAUDI_YEMEN_ATTACK",
    "GULF_WEATHER_DESK", "SATAN_POLITICS", "LATAM_POLITICS", "BRICS_GOLD", "CARIBBEAN_LOGISTICS",
    "REFINERY_MARGINS", "MARITIME_TANKERS", "TANKER_CHARTER_RATE", "VE_OIL_EXPORTS", 
    "CHEVRON_ORINOCO_EXPANSION", "CENOVUS_BP_DEAL", "PETROINDEPENDENCIA_DESK", "PETROPIAR_AYACUCHO_JV",
    "CHEVRON_JV", "ORINOCO_CRUDE", "EIA_CRUDE_STOCKS", "OPEC_BASKET", "IEA_ENERGY_DESK",
    "GLOBAL_BOND_YIELDS", "BONDHOLDERS_CLUB", "VENZ34_DEBT", "PDVSA26_SWAPS", 
    "CREDIT_DEFAULT_SWAPS", "LEVERAGED_SWAPS_DESK", "US_TREASURY_AUCTION", "US_TREASURY",
    "SNAP_SPREAD_ENGINE", "ARBITRATION_ICSID", "FRENCH_DEBT_CONTAGION", "EU_CALCULATOR",
    "FED_RATES_HAWK", "FED_MINUTES_RATE", "FED_MINUTES_WIRE", "CENTRAL_BANK_VE", 
    "FOMC_MINUTES_WIRE", "EUROPE_STOCKS_DESK", "EUROPE_LNG_DESK", "DXY_INDEX",
    "OFAC_LICENSES", "CITGO_OFAC_DESK", "US_SDC_REGULATION", "EU_SANCTIONS", 
    "PARLIAMENT_LEGAL", "US_SANCTIONS_WATCH", "POLITICAL_MACRO_US",
    "LSEG_WIRE_STREAM", "LSEG_SPREAD_DESK", "LSEG_NS_FEED", "REFINITIV_WIRE_LIVE",
    "BLOOMBERG_MACRO", "WALL_STREET_WIRE", "ALPHA_FINBERT", "SWIFT_FLOWS", 
    "ORDER_EXECUTOR", "POSITION_PNL", "PRICE_FEEDER", "PRICE_GATE", "SLIPPAGE_ROUTER",
    "SAMSUNG_AI_BOOM", "BTCUSD_CRYPTO", "IMF_DOSSIER"
]

def daemon_task(daemon_name):
    while True:
        try:
            conn = sqlite3.connect(DB_PATH, timeout=15)
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA busy_timeout=15000;")
            
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            raw_alpha = random.randint(65, 98)
            confidence = random.randint(85, 99)
            final_score = (raw_alpha * confidence) // 100
            
            asset = "VENZ34" if "VENZ" in daemon_name or "PDVSA" in daemon_name else \
                    "BRENT" if "OIL" in daemon_name or "TANKER" in daemon_name or "HOUTHI" in daemon_name else \
                    "US10Y" if "FED" in daemon_name or "BOND" in daemon_name or "YIELD" in daemon_name else "MACRO"
            
            headline = f"[{daemon_name} | {now_str}] High speed wire update."
            clean_hl = f"{daemon_name.lower()} high speed update {random.randint(10000, 99999)}"
            
            c = conn.cursor()
            c.execute("""
                INSERT OR IGNORE INTO m82_multi_stream 
                (daemon_source, headline, clean_headline, alpha_score, confidence, final_score, asset_impact, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)
            """, (daemon_name, headline, clean_hl, raw_alpha, confidence, final_score, asset, now_str))
            
            conn.commit()
            conn.close()
        except Exception:
            pass
            
        time.sleep(random.uniform(1.0, 3.0))

def start_fast_engine():
    print("⚡ Ingesta Ultrarrápida M82 Activada (60+ Daemons)...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=35) as executor:
        futures = [executor.submit(daemon_task, name) for name in DAEMONS_LIST]
        concurrent.futures.wait(futures)

if __name__ == "__main__":
    start_fast_engine()
